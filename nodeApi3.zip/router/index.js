const router = require('express').Router();
const routes = require('fs').readdirSync(`${process.env.ROOT}/router/routes`);

module.exports = async (app) => {
	for (const route of routes) {
		let functions = [];
		const { method, url, logic, auth, bucket, uploadFolder } = require(`${process.env.ROOT}/router/routes/${route}`)();
		
		if (auth) { functions.push(app.auth); } // middleware/index.js => already registed : app.auth = function (req, res, next) {...}

		if (uploadFolder) { functions.push(app.upload(bucket, uploadFolder)); }
		
		functions.push(app.transaction(logic));
		
		router[method](url, ...functions); // auth(req, res, next) => upload(req, res, next) => trans(...) => logic(...)
	}

	return router;
};