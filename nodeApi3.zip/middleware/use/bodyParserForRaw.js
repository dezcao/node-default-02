const bodyParser = require('body-parser');

module.exports = bodyParser.raw();
